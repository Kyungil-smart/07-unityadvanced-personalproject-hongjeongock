using UnityEngine;

public class PlayerInteractor : MonoBehaviour
{
    [Header("필수 참조")]
    [SerializeField] private Camera playerCamera;
    [SerializeField] private PlayerInputGate inputGate;

    [Header("레이캐스트 설정")]
    [SerializeField] private float interactDistance = 3f;

    [SerializeField] private LayerMask interactLayer;

    [Header("레이캐스트 기준 카메라")]
    [SerializeField] private Camera PlayerCamera;

    [Header("상호작용 거리")]
    [SerializeField] private float InteractDistance = 3f;

    [Header("상호작용 키")]
    [SerializeField] private KeyCode InteractKey = KeyCode.E;

    [Header("레이어 마스크")]
    [SerializeField] private LayerMask interactableMask = ~0;

    private IInteractable _current;

    private IInteractable _target;

    private void Awake()
    {
        if(playerCamera == null)
        {
            playerCamera = Camera.main;
        }
    }

    private void Update()
    {
        DetectInteractable();

        if(_current != null)
        {
            _current.LockOn(true);
        }
        if (inputGate != null && inputGate.IsLocked)
        {
            _target = null;
            return;
        }

        FindTarget();

        if (_target != null && Input.GetKeyDown(KeyCode.E))
        {
            _target.Interact(gameObject);
        }

        Debug.DrawRay(playerCamera.transform.position,
              playerCamera.transform.forward * interactDistance,
              Color.red);
    }

    private void FindTarget()
    {
        _target = null;

        // 1) 레이 생성(카메라 위치에서 정면)
        var ray = new Ray(playerCamera.transform.position, playerCamera.transform.forward);

        // 2) 레이캐스트(상호작용 마스크 기준)
        if (Physics.Raycast(ray, out RaycastHit hit, interactDistance, interactableMask))
        {
            // ✅ 지금 레이가 "무엇"을 맞추는지 확인
            Debug.Log("Hit 이름: " + hit.collider.name);
            Debug.Log("Hit 레이어: " + LayerMask.LayerToName(hit.collider.gameObject.layer));

            // ✅ 맞춘 오브젝트(또는 부모)에서 IInteractable 찾기
            _target = hit.collider.GetComponentInParent<IInteractable>();
            Debug.Log("Interactable 존재: " + (_target != null));
        }
        else
        {
            Debug.Log("Hit 없음");
        }
    }

    private void DetectInteractable()
    {
        if(_current != null)
        {
            _current.LockOn(false);
        }

        _current = null;

        if(playerCamera == null)
        {
            return;
        }

        Ray ray = new Ray(playerCamera.transform.position, playerCamera.transform.forward);

        if (Physics.Raycast(ray, out RaycastHit hit, interactDistance, interactableMask))
        {
            _current = hit.collider.GetComponentInParent<IInteractable>();

            if (_current != null)
            {
                _current.LockOn(true);
            }
        }
    }
}